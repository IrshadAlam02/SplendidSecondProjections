#include <stdio.h>
// int main()
// {
// printf(" hello c prgram :");
//   return 0;
// }

// second program arithmetic operation

// #include <stdio.h>
// int main()
// {int a,b;
//  printf("enter the value of a and b :");
//  scanf("%d %d",&a,&b);
//  int mul = a * b;
//  int rem = a / b;
//  int add = a + b;
//  int sub = a - b;
//  printf("this is multiplication :%d\n",mul);
//  printf("this is remainder :%d\n",rem);
//  printf("this is addition :%d\n ",add);
//  printf("this is subtraction :%d\n ",sub);

//   return 0;
// }

// to conver th etemhrature to fharran

// #include <stdio.h>
// int main()
// { int temp,cel;
// printf("enter the value of temp :");
//  scanf("%d %d",&temp,&cel);
//  cel = (temp - 32) * 5/9;
//  temp = (9/5 * cel) + 32;
//  printf("this is centigrade : %d\n",cel);
//  printf("this is farenheit : %d\n",temp);

//   return 0;
// }

// area of circle,square,triangle,rectangle

// #include <stdio.h>
// int main()
// {int a,b,h;
// printf(" area of circle :\n area of square,area of triangle :\n area of
// rectangle :\n");
//  scanf("%d %d %d",&a,&b,&h);
//  float circle = 3.14 * a * a;
//  float square = a * a;
//  float triangle = .5 * b * h;
//  float rectangle = a * b;
//  printf("this is circle :%f\n",circle);
//  printf("this is square :%f\n",square);
//  printf("this is triangle :%f\n",triangle);
//  printf("this is rectangle :%f\n",rectangle);

//   return 0;
// }

// swap to number

// #include <stdio.h>
// int main()
// { int a,b,c;
// printf("enter thr value of a and b:");
//  scanf("%d %d",&a,&b);
//  c = a;
//  a = b;
//  b = c;
//  printf("this is a :%d\n this is b : %d",a,b);

//   return 0;
// }

// #include <stdio.h>
// int main()
// { int a,b,c;
// printf("enter thr value of a and b:");
//  scanf("%d %d",&a,&b);
//  a = a + b;
//  b = a - b;
//  a = a - b;
//  printf(" a is :%d\n  b is : %d",a,b);

//   return 0;
// }

// simple intrest

// #include <stdio.h>
// int main()
// {
//   float A,P,r,t;
//     printf(" enter simple interst value :");
//     scanf("%f %f %f %f",&A,&P,&r,&t);
//  A = P*(1+r*t);
//   printf("this is simple intrest :%f",A);

//   return 0;
// }

// looping if else

// #include <stdio.h>
// int main()
// {
//   int n;
// printf(" enter the number  :");
//   scanf("%d",&n);
//   if( n%2 == 0)
//   {
//     printf("this is even number %d\n",n);
//   }
//   else
//   {
//     printf("this is odd number:%d\n ",n);
//   }

//   return 0;
// }

// leaf year

// #include <stdio.h>
// int main()
// {
//   int year;
// printf("enter the year :");
//   scanf("%d",&year);
//   if(year%4 == 0|| year % 400 == 0 && year % 100 != 0)
//   {
//     printf("this is leaf year :%d",year);
//   }
//   else
//   {
//     printf("this is not leaf year :%d",year);
//   }
//   return 0;
// }

// grestest among three number

// #include <stdio.h>
// int main()
// {
//   int a,b,c;
// printf(" enter the three values :");
//   scanf(" %d %d %d",&a,&b,&c);
//   if(a>b && a>c)
//   {
//     printf("this is greatest number :%d",a);
//   }
//   else if (b>a && b>c)
//     {
//       printf("this is greatest number :%d",b);
//     }
//   else
//     {
//       printf("this is greatest number :%d",c);
//     }
//   return 0;
// }

// week  day
// #include <stdio.h>
// int main()
// {
//   int day;
//   printf("Enter the day (1-7): ");
//   scanf("%d", &day);
//   switch(day)
//   {
//     case 1:printf("Sunday");break;
//     case 2:printf("Monday");break;
//     case 3: printf("Tuesday");break;
//     case 4:printf("Wednesday");break;
//     case 5: printf("Thursday");break;
//     case 6:printf("Friday"); break;
//     case 7:printf("Saturday");break;
//     default:printf("Invalid input");
//   }
//   return 0;
// }

// compute a factorial

// #include <stdio.h>
// int main()
// {
//   int n,fact=1;
// printf("enter the factorial :");
//   scanf("%d",&n);
//   for(int i = 1; i<=n; i++)
//     {
//        fact = fact * i;

//     }
//   printf("this is factorial :%d",fact);

//   return 0;
// }

// fibonacci series

cp() {
  int n, fib3 = 1;
  printf("enter the number :");
  scanf("d", &n);
  int fib1 = 0;
  int fib2 = 1;
  printf("%d %d", fib1, fib2);
  for (int i = 0; i <= n; i++) {
    fib3 = i + fib3;
    printf("%d this is fubonacci series :", fib3);
  }
  return 0;
}

// today  is done thanks

// revrese

// #include <stdio.h>
// int main()
// {
//   int n,rev=0;
// printf("enter a number: ");
//   scanf("d",&n);
//   int m = n;
//   while(n!=0)
//     {
//       int digit = n % 10;
//       rev =(rev * 10) + digit;
//       n = n/10;
//     }
//   printf("this is reverse :%d is %d",m,rev);

//   return 0;
// }

// 1 D array

// #include <stdio.h>
// int main()
// {
//   int n;
//   printf(" enter the size of array :");
//   scanf("%d",&n);
//   int name[] = {1,2,3,45,6,7,8,9};
//   for(int i = 0; i<n; i++)
//     {
//       printf("enter the value of array :");
//       scanf("%d",name[i]);
//     }

//   return 0;
// }
// {

//   char a[20];
//   char b[20];
//   printf("enter the first name :");
//   scanf("%[^\n]s",a);
//   printf("enter the last name :");
//   scanf("%s",b);

//   int size=0;
//   while(a[size]!='\0')
//     {
//       size++;
//     }

//   for ( int i=size,j=0; b[j]!='\0';i++,j++)
//     {
//       a[i]=b[j];
//     }

//   for (int i=0;i<a[i]!='\0';i++)
//     {
//       printf("%c",a[i]);
//     }
// }

// given number is prime or not

 cp15()
{
  int  n;
  printf("enter thr number :");
  scanf("%d", &n);
  if(n==1 || n==2) 
  {
    printf("this is prime number :%d",n);
  }
  for (int i = 2; i < n; i++)
    {
    if (n % i == 0) {
      printf("%d this is not prime number", n);
      break;
    }

    else if (i > n / 2) {
      printf(" %d this is prime number", n);
      break;
    }
  }

  return 0;
}
// find palindrome number

int n() {
  int n;
  printf("enter the number :");
  scanf("%d", &n);
  int m = n;
  int rev = 0;
  while (n != 0) {
    int digit = n % 10;
    rev = (rev * 10) + digit;
    n = n / 10;
  }
  if (m == rev) {
    printf("%d this number is palandrome:", m);
  } else {
    printf("%d this number is not a palandrome:", m);
  }
  return 0;
}

// range of prime number error
int g() {
  int n, count = 0, i, n1, n2;
  printf("enter the starting and ending number :");
  scanf("%d %d", &n1, &n2);
  for (int n = n1; n <= n2; n++) {
    count = 0;
  }
  for (int i = 1; i <= n; i++) {
    if (n % i == 0) {
      count++;
    }
  }
  if (count == 1 || count == 2) {
    printf("%d", n);
  }
  return 0;
}

// menu of arthimatic operation

int f() {
  int ch;
  float a, b, result;

  do {
    printf("\n**************\n\nMENU\n\n1.addition\n2.subtraction\n3."
           "multiplication\n4.division\n5.exit\n***************");
    printf("enter your choice :");
    scanf("%d", &ch);
    switch (ch) {
    case 1:
      printf("enter two values :");
      scanf("%f %f", &a, &b);
      result = a + b;
      printf("%2f + %2f=%2f", a, b, result);
      break;

    case 2:
      printf("enter two values :");
      scanf("%f %f", &a, &b);
      result = a - b;
      printf("%2f - %2f=%2f", a, b, result);
      break;

    case 3:
      printf("enter two values :");
      scanf("%f %f", &a, &b);
      result = a * b;
      printf("%2f * %2f=%2f", a, b, result);
      break;

    case 4:
      printf("enter two values :");
      scanf("%f %f", &a, &b);
      result = a / b;
      printf("%2f/ %2f=%2f", a, b, result);
      break;

    case 5:
      printf("**thanks for using calculater");
      break;

    default:
      printf("invalid choice");
    }

  } while (ch != 5);
  return 0;
}

// revese of number in arrry

int lab23() {
  int n;
  printf("enter the size of the arry:");
  scanf("%d", &n);
  int arr[n];
  printf("enter the arry elements:");
  for (int i = 0; i < n; i++)
    {
    scanf("%d", &arr[i]);
  }
  printf("reverse is :");
  for (int i = 0; i < n; i++) 
  {
    printf("%d", arr[n - i - 1]);
  }

  return 0;
}

// posutive negative zerro

void lab24() {
  int n;
  printf("enter the size of the arry:");
  scanf("%d", &n);
  int arr[n];
  printf("enter the arry elements:");
  for (int i = 0; i < n; i++) {
    scanf("%d", &arr[i]);
  }
  int zero = 0, postive = 0, negative = 0;
  for (int i = 0; i < n; i++) 
  {
    if (arr[i] == 0) 
    {
      zero++;
    } else if (arr[i] > 0) 
    {
      postive++;
    } else 
    {
      negative++;
    }
  }
  printf("the number of zero is :%d\n", zero);
  printf("the number of positive is :%d\n", postive);
  printf("the number of negative is :%d\n", negative);
}

int power(int x, int y) 
{
  if (y == 0)
    return 1;
  else
    return x * power(x, y - 1);
}

float x()
{ return 2.1; }

void lab25() {
  int n;
  printf("enter the size of the arry:");
  scanf("%d", &n);
  int arr[n];
  printf("enter the arry elements:");
  for (int i = 0; i < n; i++) 
  {
    scanf("%d", &arr[i]);
  }
  int max = arr[0], min = arr[0];
  for (int i = 0; i < n; i++)
    {
    if (arr[i] > max)
    {
      max = arr[i];
    }
    else if (arr[i] < min)
    {
      min = arr[i];
    }
  }
  printf("the max is :%d\n", max);
  printf("the min is :%d\n", min);
}

void lab26() {
  int n;
  printf("enter the size of the arry:");
  scanf("%d", &n);
  int arr[n];
  printf("enter the arry elements:");
  for (int i = 0; i < n; i++) {
    scanf("%d", &arr[i]);
  }
  printf("this is acending order:");
  int acc = arr[0];
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n - 1; j++) {
      if (arr[j] > arr[j + 1]) {
        int swap = arr[j];
        arr[j] = arr[j + 1];
        arr[j + 1] = swap;
      }
    }
  }
  for (int i = 0; i < n; i++)
    {
    printf("%d ", arr[i]);
  }
  printf("\nthis is decinding order:");
  for (int i = 0; i < n; i++) 
  {
    printf("%d ", arr[n - i - 1]);
  }
}

void lab27() {
  int n, m;
  printf("enter the size of the arry:");
  scanf("%d", &n);
  int arr[n];
  printf("enter the arry elements:");
  for (int i = 0; i < n; i++) {
    scanf("%d", &arr[i]);
  }
  printf("enter the element to be searched :");
  scanf("%d", &m);
  for (int i = 0; i < n; i++)
    {
    if (arr[i] == m) 
    {
      printf("the element is found at %d", i);
      break;
    }
  }
}

// thank for today

void lab28() {
  int n, m;
  printf("enter the array size : ");
  scanf("%d %d", &n, &m);
  int num1[n][m];
  for (int i = 0; i < n; i++) 
  {
    printf("enter %d row numbers : ", i + 1);
    for (int j = 0; j < m; j++)
      {
      scanf("%d", &num1[i][j]);
    }
  }

  int k, l;
  printf("enter the array size : ");
  scanf("%d %d", &k, &l);
  int num2[k][l];
  for (int i = 0; i < n; i++) {
    printf("enter %d row numbers : ", i + 1);
    for (int j = 0; j < l; j++) {
      scanf("%d", &num2[i][j]);
    }
  }

  int ans;
  for (int i = 0; i < n; i++) {
    ans = 0;
    for (int j = 0; j < m; j++) {
      ans = num1[i][j] + num2[i][j];
      printf("%d\t", ans);
    }
    printf("\n");
  }
}

void lab30() {
  int a = 0;

  for (int i = 0; a < 5; a = i++) {
    printf("%d\n", i);
  }
}
// void lab31()
//   struct student
// {
//   float marks;
//   char name[30];
// };
// int main()
// {
//   struct student[2];
//   for(int i=0;i<2;i++)
//     {
//       printf("enter %d roll no student name or marks",i+1);
//       scanf("%s %f",&s[i]name,&s[i]marks);
//     }
//   for(int i=0;i<2;i++)
//     {
//       printf("roll no %d \n name=%s \n marks=%f \n",i+1,s[i]name,s[i]marks);
//     }

// }
int lab29() {
  int n, m;
  printf("enter the size of matrix: ");
  scanf("%d %d", &n, &m);
  int matrix1[n][m];
  for (int i = 0; i < n; i++) {
    printf("enter the %d matrix row number : ", i + 1);
    for (int j = 0; j < m; j++) {
      scanf("%d", &matrix1[i][j]);
    }
  }
  int k, l;
  printf("enter the size of matrix: ");
  scanf("%d %d", &k, &l);
  int matrix2[k][l];
  for (int i = 0; i < k; i++) {
    printf("enter the %d matrix row number : ", i + 1);
    for (int j = 0; j < l; j++) {
      scanf("%d", &matrix2[i][j]);
    }
  }
  printf("the multiplication of matrix is :\n");
  int op, ans = 0;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < l; j++) {
      for (int s = 0; s < m; s++) {
        op = matrix1[i][s] * matrix2[s][j];
        ans += op;
      }
      printf("%d\t", ans);
      ans = 0;
    }
    printf("\n");
  }
  return 0;
}
int lab32() {
  int n, m;
  printf("entter the size of array:");
  scanf("%d %d", &n, &m);
  int matrix1[n][m];
  for (int i = 0; i < n; i++) {
    printf("enter the martrix row number %d :", i + 1);
    for (int j = 0; j < m; j++) {
      scanf("%d", &matrix1[i][j]);
    }
  }

  printf("the matrix is transpose :\n");
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      printf("%d\t", matrix1[j][i]);
    }
    printf("\n");
  }
  return 0;
}
int lab33() {
  int ch;
  printf("\t********************************\n MENU\n1) for copy string\n2) "
         "for  reverse the string\n");
  printf("enter your chose:");
  scanf("%d", &ch);
  switch (ch) {
    char name[100];
    char copy[100];

  case 1:
    printf("enter the name :\n");
    scanf("%[^\n]s", name);
    for (int i = 0; name[i] != '\0'; i++) {
      copy[i] = name[i];
    }
    printf("the copied string is : %s\n", copy);
    break;

    char length = strlen(name);

  case 2:
    for (int i = 0; i < length / 2; i++) {
      char store = name[i];
      name[i] = name[length - 1 - i];
      name[length - 1 - i] = store;
    }
    printf("the string is  reverse: %s", name);
    break;
  }
}

int lab34() {
  int n, m;
  printf("enter the size of array:");
  scanf("%d", &n);
  int arry[n];
  printf("enter the array elements:");
  for (int i = 0; i < n; i++) {
    scanf("%d", &arry[i]);
  }
  printf("enter the number to be searched:");
  scanf("%d", &m);
  int *p;
  p = arry;
  for (int i = 0; i < n; i++) {
    if (m == *p) {
      printf("the number is found at %d position", i);
      break;
    }
    p++;
  }
  return 0;
}

int lab35() {
  int n;
  printf("enter the arry size: ");
  scanf("%d", &n);
  int arry[n];
  printf("enter the arry elements: ");
  for (int i = 0; i < n; i++) {
    scanf("%d", &arry[i]);
  }
  int *p;
  p = arry;
  for (int i = 0; i < n; i++) {
    if (arry[i] % 2 == 0) {
      printf("the value of arry[%d] is even = %d\n", i, *(p + i));
    } else {
      printf("the value of arry[%d] is odd = %d\n", i, *(p + i));
    }
  }
  int add = 0;
  for (int i = 0; i < n; i++) {
    int a = *p;
    add = add + a;
    a = add;
    p++;
  }
  printf("the sum of even or odd element in arry is : %d", add);
  return 0;
}
int lab55() {
  int n, m;
  printf("enter the size of array:");
  scanf("%d", &n);
  int arr[n];
  printf("enter the array elements:");
  for (int i = 0; i < n; i++) {
    scanf("%d", &arr[i]);
  }
  printf("enter the number to be searched:");
  scanf("%d", &m);
  for (int i = 0; i < n; i++) {
    if (m == arr[i]) {
      printf("the number is found at %d position\n", i);
    }
  }
}
