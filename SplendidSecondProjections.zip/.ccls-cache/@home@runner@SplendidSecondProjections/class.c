int cp1()
{
  int  n,m;
  printf("enter two number :");
  scanf("%d %d",&n,&m);
  int sum = n+m;
  int sub = n-m;
  int mul = n*m;
  int  div = n/m;
  printf("the sum of two number is : %d\n",sum);
  printf("the sub of two no : %d\n",sub);
  printf("the mul of two no : %d\n",mul);
  printf("the div of two no : %d\n",div);
  return 0;
}
  int cp2()
{
 float temp ,far;
  printf("enter the temp in celsius : ");
  scanf("%f",&temp);
  printf("enter the temp in far : ");
  scanf("%f",&far);
  far = (temp*9/5) +32;
  temp = (far-32)*5/9;
  printf("the temp in far is : %f\n",far);
  printf( "the temp in celsius is : %f\n",temp);
  return 0;

}
int cp3()
{
  int cir,tri,squ,base,height,side,radius;
  printf("enter the radius of circle : ");
  scanf("%d",&radius);
  printf("enter the base and hight of triangle : ");
  scanf("%d %d",&base,&height);
  printf("enter the side of square : ");
  scanf("%d",&side);
  cir = 2*3.14*radius;
  tri = 0.5*base*height;
  squ = side*side;
  printf( "the cir of circle is : %d\n",cir);
  printf("the tri of triangle is : %d\n",tri);
  printf("the squ of square is : %d\n",squ);
  return 0;
}
int cp4()
{
  int a,b,c;
  printf("enter the value of a and b : ");
  scanf("%d %d",&a,&b);
  c=a;
  a=b;
  b=c;
  printf("the value of a is : %d %d\n",a,b);
}
int cp5()
{
  int n;
  printf("enter the number : ");
  scanf("%d",&n);
  if(n%2==0)
  {
    printf("the number is even");
  }
  else
  {
    printf("the number is odd");
  }
  
}
int cp6()
{
  int p,t,r;
  printf("enter the amount: ");
  scanf("%d",&p);
  printf("enter the rate: ");
  scanf("%d",&r);
  printf("enter the time: ");
  scanf("%d",&t);
  int simple = p*t*r/100;
  printf("the simple intrest is : %d\n",simple);
}
  int cp7()
{
  int year;
  printf("enter the year : ");
  scanf("%d",&year);
  if(year %400 ==0 || year % 4==0 && year % 100 !=0)
  {
    printf("the year is leap year");
    
  }
  else 
  {
    printf("the year is not leap year");
  }
  
  
  
}
int cp8()
{
  {
    int a,b,c;
    printf("enter the three number :");
    scanf("%d%d%d",&a,&b,&c);
    if(a>b && a>c)
    {
      printf("a is gretest amoung three number:%d\n",a);
  }
  else if(b>a && b>c)
  {
   printf("b is gretest amoung three number:%d\n",b);
  }
  else
  {
   printf("c is gretest amoung three number:%d\n",c);
  }
  return 0;
  }
}
int cp9()

{
  char name[20];
int math,sci,sst,pfps,eng;
printf("enter the name:");
scanf("%[^\n]s",name);
printf("enter the math marks:");
scanf(" %d",&math);
printf("enter the sci marks:");
scanf("%d",&sci);
printf("enter the sst marks:");
scanf("%d",&sst);
printf("enter the pfps marks:");
scanf("%d",&pfps);
printf("enter the eng marks:");
scanf("%d",&eng);
  int sum = math+sci+sst+pfps+eng;
  
int per = (sum / 500 )*100;
  
if(per >= 90)
{
printf("grade A");
}
else if(per >= 80 &&per < 90)
{
printf("grade B");
}
else if(per >= 70 &&per <80)
{
printf("grade C");
}
else if(per >= 50 &&per <70)
{
printf("grade D");
}
else if(per >= 36 && per<50)
{
printf("grade E");
}
else if (per < 36)
{
printf("grade F");
}
return 0;
}
 int cp10()
{
  int x,y,i=1,p=1;
  printf("enter the base : ");
  scanf("%d",&x);
  printf("enter the power : ");
  scanf("%d",&y);
  while (i <=y)
    {
       p =p*x;
      i++;
    }
  printf("the power of number is : %d",p);
  return 0;
}
int cp11()
{
  int fact =1,n;
  printf("enter the number : ");
  scanf("%d",&n);
  for(int i=1;i<=n;i++)
    {
      fact = fact*i;
    }
  printf("the factorial of number is : %d",fact);
  
}
int cp12()
{
  int n,m;
  printf("enter the number : ");
  scanf("%d",&n);
  n=m;
 while(n!=0)
   {
     int digit=n%10;
     printf("%d",digit);
     n=n/10;
   }
   
}
int cp13()
{
  int n,sum=0;
  printf("enter the number : ");
  scanf("%d",&n);
  while(n!=0)
    {
      int digit = n%10;
      sum=sum+digit;
      n=n/10;
    }
    printf("the sum of indivisble is : %d",sum);
  
}
int cp14()  
{
  int n,m;
  printf("enter the arry size : ");
  scanf("%d %d",&n,&m);
  int arr[n][m];
  for(int i=0; i<n ;i++)
    {
      printf("enter the row %d :",i+1);
    for(int j=0; j<m ;j++)
  {
    scanf("%d",&arr[i][j]); 
  }
    } 
  int k,l;
  printf("enter the arry size : ");
  scanf("%d %d",&k,&l);
  int arr1[k][l];
  for(int i=0; i<k ;i++)
    {
      printf("enter the row %d :",i+1);
    for(int j=0; j<l ;j++)
  {
    scanf("%d",&arr1[i][j]); 
  }
    } 
  int ans;
  for(int i=0; i<n ;i++)
    {
    ans =0;
    for(int j=0; j<m ;j++)
      {
        ans = arr[i][j]+arr1[i][j];
        printf("\t%d",ans);
      }
      printf("\n");
  }
      
}
cp19()
{
int n;
printf("enter the size of the arry:");
scanf("%d", &n);
int arr[n];
printf("enter the arry elements:");
for (int i = 0; i < n; i++) 
{
  scanf("%d", &arr[i]);
}
  int max = arr[0], min = arr[0];
  for (int i = 0; i < n; i++)
    {
      if(arr[i]>max)
      {
        max = arr[i];
      }
      if(arr[i]<min)
      {
        min = arr[i];
      }
    }
  printf("the max number is : %d\n",max);
  printf("the min number is : %d\n",min);  
}
// // #include <stdio.h>
// void swap(int x,int y)
// {
//   int c =x;
//   x=y;
//   y=c;
// }
// void swap1(int *a,int *b)
// {
//   int c=*a;
//   *a=*b;
//   *b=c;
// }
// int main()
// {
//   int a,b;
//   printf("enter the value of a and b :");
//   scanf( "%d %d",&a,&b);
//   swap(a,b);
//   printf("the value of a and b after swaping is : %d %d\n",a,b);
//   swap1(&a,&b);
//   printf("the value of a and b after swaping is : %d %d\n",a,b);
// }

int cp32()
{
  char name[20];
  int weight;
  int height;
  printf("Enter your name :");
  scanf("%[^\n]s",name);
  printf("Enter the weight :");
  scanf("%dkg",&weight);
  printf("Enter the height :");
  scanf("%d",&height);
  printf(" \n***** \t THIS IS YOUR DIET PLAN ***** \n\n");
  int protien  = weight*1.5;
  int carb = weight*5;
  int fiber = weight*.6;
  int fat = weight*0.5;
  int totalcaloie = (protien+carb+fiber+fat)*7.716179 ;
  printf(" This is your name     : %s\n\n",name);
  printf(" This is your weigh    : %dkg\n\n",weight);
  printf(" This is your height   : %dft\n\n",height);
  printf(" ******* This is your daily goal ******\n\n");
  printf(" Protien in gram      : %dg\n\n",protien);
  printf(" Carb in gram         : %dg\n\n",carb);
  printf(" Fiber in gram        : %dg\n\n",fiber);
  printf(" Fat in gram          : %dg\n\n",fat);
  printf(" Total caloie in gram : %dg\n\n",totalcaloie);
  printf("***** BEST OF LUCK FOR YOUR GAIN WEIGHT******");
  
}

int cp33()
{
  char x[20];
  int key;
  printf("enter the character :");
  scanf("%[^\n]s",x);
  printf("enter the key :");
  scanf("%d",&key);
  for(int i=0; x[i]!='\0';i++)
    
    {
      
        if(x[i]>=97 && x[i]<=122)
        {
         x[i]=x[i]-26;
        }
      else
        {
          x[i]=x[i]+key;
          
        }
          
      
    }
  
  printf("the character is : %s",x);
  
}
int cp34()
{
  long double n,fact=1;
  printf("enter any number :");
  scanf("%Lf",&n);
   if(n<=0)
   {
     printf("invalid number");
   }
  else if(n>0)
  {
    for(int i=1;i<=n;i++)
      {
        fact=fact*i;
      }
    printf("this is your factorial %.0Lf",fact);
  }
  
}
    
  
 


