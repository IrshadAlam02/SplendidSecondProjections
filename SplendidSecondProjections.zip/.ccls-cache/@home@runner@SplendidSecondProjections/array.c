#include <stdio.h>
#include <string.h>
// int m(){
// char b;
// int stdno,i,marks,r; 
//   printf("enter the number of student in your class : ");
//   scanf("%d",&stdno);
           
//   int irshad[stdno];
//   for(i=0; i<stdno; i++)
//   {
//       printf("enter a roll no %d marks ",i+1);
//       scanf("%d",&irshad[i]);
//   }
//  printf("enter the value in y/n:");
//  scanf("%s",&b);
//  if(b=='y')
//  {
//    printf("enter the roll no to be searched : ");
//    scanf("%d",&r);
   
//    printf("roll no %d marks is %d /n",r,irshad[r-1]);
//    (irshad[r-1]<36) ? printf("fail"):printf("pass");
//  }   
//  else{
//    printf("thank you for your time");
   
//  }
int main()
{
 cp34();
  
}
